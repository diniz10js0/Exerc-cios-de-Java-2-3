public class Solucao72 {
    public static void main(String[] args) {
        
        int numero1 = 10; 
        int numero2 = 25; 
        int numero3 = 15; 

        // Armazenando o maior numero na variavel maior
        int maior = numero1;

        if (numero2 > maior) {
            maior = numero2;
        }
        if (numero3 > maior) {
            maior = numero3;
        }

        // Imprimindo o maior numero
        System.out.println("O maior numero e: " + maior);
    }
}
