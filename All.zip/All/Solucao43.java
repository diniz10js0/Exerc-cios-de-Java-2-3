public class Solucao43 {
    public static void main(String[] args) {
        
        double numero = -4; // Você pode alterar este valor

        // Verificando se o numero e positivo ou negativo
        if (numero > 0) {
            // Calculando e imprimindo a raiz quadrada
            double raizQuadrada = Math.sqrt(numero);
            System.out.println("A raiz quadrada de " + numero + " e: " + raizQuadrada);
        } else {
            // Calculando e imprimindo o quadrado
            double quadrado = numero * numero;
            System.out.println("O quadrado de " + numero + " e: " + quadrado);
        }
    }
}

