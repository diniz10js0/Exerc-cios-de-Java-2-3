public class Solucao27 {
    public static void main(String[] args) {
        // Imprimindo números múltiplos de 5 de 1 a 500
        for (int i = 1; i <= 500; i++) {
            if (i % 5 == 0) {
                System.out.println(i);
            }
        }
    }
}
