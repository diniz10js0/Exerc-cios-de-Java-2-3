public class Solucao25 {
    public static void main(String[] args) {
        // Simulando a entrada de nomes
        String[] nomesDigitados = {"Julia", "Gustavo", "Renato", "FIM", "Michele"}; 
        // Percorrendo os nomes digitados
        for (String nome : nomesDigitados) {
            if (nome.equals("FIM")) {
                break; // Encerrar ao encontrar "FIM"
            }
            System.out.println(nome); // Imprimir o nome
        }
    }
}
