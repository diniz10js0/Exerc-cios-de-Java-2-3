public class Solucao44 {
    public static void main(String[] args) {


        int num1 = 15; // Você pode alterar este valor
        int num2 = 5;  // Você pode alterar este valor
        int num3 = 10; // Você pode alterar este valor

                int[] numeros = {num1, num2, num3};

        // Ordenando os números usando um algoritmo simples de ordenaçao 
                for (int i = 0; i < numeros.length - 1; i++) {
            for (int j = 0; j < numeros.length - 1 - i; j++) {
                if (numeros[j] > numeros[j + 1]) {
                    // Troca de posiçoes
                    int temp = numeros[j];
                    numeros[j] = numeros[j + 1];
                    numeros[j + 1] = temp;
                }
            }
        }

        // Imprimindo os numeros em ordem crescente
        System.out.println("Numeros em ordem crescente:");
        for (int numero : numeros) {
            System.out.println(numero);
        }
    }
}
