public class Solucao22 {
    public static void main(String[] args) {
        // Imprimindo os 100 primeiros números pares
        for (int i = 1; i <= 100; i++) {
            System.out.println(i * 2);
        }
    }
}
