public class Solucao54 {
    public static void main(String[] args) {
    
        int numero = 1234; 

        // Extraindo os algarismos das unidades de milhar e das centenas
        int unidadesMilhar = numero / 1000;           // Algoritmo da unidade de milhar
        int centenas = (numero / 100) % 10;            // Algoritmo da centena

        // Formando o novo numero
        int novoNumero = (unidadesMilhar * 10) + centenas;

        // Verificando se o novo numero e multiplo de 4
        if (novoNumero % 4 == 0) {
            System.out.println("O numero " + novoNumero + " e multiplo de 4.");
        } else {
            System.out.println("O numero " + novoNumero + " nao e multiplo de 4.");
        }
    }
}
