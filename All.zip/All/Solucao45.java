public class Solucao45 {
    public static void main(String[] args) {
        // Simulando a entrada de um numero
        int numero = 50; // Você pode alterar este valor

        // Verificando se o numero está entre 20 e 90
        if (numero >= 20 && numero <= 90) {
            System.out.println("O numero " + numero + " esta compreendido entre 20 e 90.");
        } else {
            System.out.println("O numero " + numero + " não esta compreendido entre 20 e 90.");
        }
    }
}
