public class Solucao53 {
    public static void main(String[] args) {
                int numero = 345;         // Extraindo o algarismo das dezenas
        int dezenas = (numero / 10) % 10;

        // Verificando se o algarismo das dezenas e par ou ímpar
        if (dezenas % 2 == 0) {
            System.out.println("O algarismo da casa das dezenas (" + dezenas + ") e par.");
        } else {
            System.out.println("O algarismo da casa das dezenas (" + dezenas + ") e impar.");
        }
    }
}
