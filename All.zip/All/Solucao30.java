public class Solucao30 {
    public static void main(String[] args) {
        // Simulando a entrada de numeros
        int[] numerosDigitados = {12, 15, 20, -999, 30}; 
        // Percorrendo os numeros digitados
        for (int numero : numerosDigitados) {
            if (numero == -999) {
                break; // Encerrar ao encontrar -999
            }

            System.out.println("Divisores de " + numero + ":");
            imprimirDivisores(numero);
            System.out.println(); 
        }
    }

    public static void imprimirDivisores(int numero) {
        for (int i = 1; i <= numero; i++) {
            if (numero % i == 0) {
                System.out.println(i); // Imprime o divisor
                  }
        }
    }
}
