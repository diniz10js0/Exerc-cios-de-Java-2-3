public class Solucao6 {
    public static void main(String[] args) {
        // Definindo cinco numeros
        double num1 = 10.0;
        double num2 = 5.0;
        double num3 = 20.0;
        double num4 = 5.0;
        double num5 = 15.0;

        // Identificando o maior e o menor numero
        double[] resultado = encontrarMaiorEMenor(num1, num2, num3, num4, num5);
        System.out.println("Menor: " + resultado[0]);
        System.out.println("Maior: " + resultado[1]);
    }

    public static double[] encontrarMaiorEMenor(double a, double b, double c, double d, double e) {
        double menor = a;
        double maior = a;

        // Comparando com cada numero
        if (b < menor) {
            menor = b;
        }
        if (b > maior) {
            maior = b;
        }

        if (c < menor) {
            menor = c;
        }
        if (c > maior) {
            maior = c;
        }

        if (d < menor) {
            menor = d;
        }
        if (d > maior) {
            maior = d;
        }

        if (e < menor) {
            menor = e;
        }
        if (e > maior) {
            maior = e;
        }

        return new double[]{menor, maior};
    }
}
