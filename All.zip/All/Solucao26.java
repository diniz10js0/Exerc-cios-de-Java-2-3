public class Solucao26 {
    public static void main(String[] args) {
        // Simulando a entrada de numeros
        double[] numerosDigitados = {25, 36, 16, -999, 49};         
        // Percorrendo os numeros digitados
        for (double numero : numerosDigitados) {
            if (numero == -999) {
                break; // Encerrar ao encontrar -999
            }

            // Calculando a raiz quadrada e o inverso
            double raizQuadrada = Math.sqrt(numero);
            double inverso = 1.0 / numero;

            // Imprimindo os resultados
            System.out.println("Numero: " + numero);
            System.out.println("Raiz quadrada: " + raizQuadrada);
            System.out.println("Inverso: " + inverso);
            System.out.println();         }
    }
}
