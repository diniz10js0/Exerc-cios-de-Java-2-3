public class Solucao71 {
    public static void main(String[] args) {
      
        int numero1 = 10; 
        int numero2 = 25; 
        int numero3 = 15; 

        // Encontrando o maior numero
        int maior = numero1;

        if (numero2 > maior) {
            maior = numero2;
        }
        if (numero3 > maior) {
            maior = numero3;
        }

        // Imprimindo o maior numero
        System.out.println("O maior numero e: " + maior);
    }
}
