public class Solucao73 {
    public static void main(String[] args) {
      
        int numero1 = 10; 
        int numero2 = 25; 
        int numero3 = 15; 

        // Variaveis para armazenar os numeros
        int maior, intermediario, menor;

        // Determinando o maior, intermediario e menor
        if (numero1 > numero2 && numero1 > numero3) {
            maior = numero1;
            if (numero2 > numero3) {
                intermediario = numero2;
                menor = numero3;
            } else {
                intermediario = numero3;
                menor = numero2;
            }
        } else if (numero2 > numero1 && numero2 > numero3) {
            maior = numero2;
            if (numero1 > numero3) {
                intermediario = numero1;
                menor = numero3;
            } else {
                intermediario = numero3;
                menor = numero1;
            }
        } else {
            maior = numero3;
            if (numero1 > numero2) {
                intermediario = numero1;
                menor = numero2;
            } else {
                intermediario = numero2;
                menor = numero1;
            }
        }

        // Imprimindo os resultados
        System.out.println("Maior: " + maior);
        System.out.println("Intermediario: " + intermediario);
        System.out.println("Menor: " + menor);
    }
}
