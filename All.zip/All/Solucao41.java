public class Solucao41 {
    public static void main(String[] args) {
        // Simulando a entrada de dois numeros inteiros
        int valor1 = 5; 
        int valor2 = 8; 

        // Calculando a soma
        int soma = valor1 + valor2;

        // Verificando se a soma e maior que 10
        if (soma > 10) {
            System.out.println("A soma e: " + soma);
        }
    }
}
