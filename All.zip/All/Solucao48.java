public class Solucao48 {
    public static void main(String[] args) {
       
        int numero1 = 15; 
        int numero2 = 25; 

        // Verificando qual número e maior
        if (numero1 > numero2) {
            System.out.println("O maior numero e: " + numero1);
        } else {
            System.out.println("O maior numero e: " + numero2);
        }
    }
}
