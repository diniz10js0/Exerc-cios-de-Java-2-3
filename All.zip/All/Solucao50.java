public class Solucao50 {
    public static void main(String[] args) {
      
        int numero = 25; 

        // Verificando se o numero e divisivel por 5
        if (numero % 5 == 0) {
            System.out.println("O numero " + numero + " e divisivel por 5.");
        } else {
            System.out.println("O numero " + numero + " nao e divisivel por 5.");
        }
    }
}
