public class Solucao28 {
    public static void main(String[] args) {
        double produto = 1;

        // Calculando o produto de todos os numeros de 120 a 300
        for (int i = 120; i <= 100; i++) {
            produto *= i;
        }

        // Imprimindo o resultado
        System.out.println("O produto de todos os numeros de 120 a 300 e: " + produto);
    }
}
