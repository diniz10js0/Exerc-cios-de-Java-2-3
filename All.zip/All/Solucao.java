public class Solucao {
    public static void main(String[] args) {
        // Definindo três números diferentes
        double num1 = 15.0;
        double num2 = 10.0;
        double num3 = 20.0;

        // Armazenando os números nas variáveis maior, intermediário e menor
        double[] resultado = ordenarNumeros(num1, num2, num3);
        System.out.println("Menor: " + resultado[0]);
        System.out.println("Intermediário: " + resultado[1]);
        System.out.println("Maior: " + resultado[2]);
    }

    public static double[] ordenarNumeros(double a, double b, double c) {
        double menor, intermediario, maior;

        if (a < b && a < c) {
            menor = a;
            if (b < c) {
                intermediario = b;
                maior = c;
            } else {
                intermediario = c;
                maior = b;
            }
        } else if (b < a && b < c) {
            menor = b;
            if (a < c) {
                intermediario = a;
                maior = c;
            } else {
                intermediario = c;
                maior = a;
            }
        } else {
            menor = c;
            if (a < b) {
                intermediario = a;
                maior = b;
            } else 
