public class Solucao46 {
    public static void main(String[] args) {
      
        int numero = 20; // Você pode alterar este valor

        // Verificando o valor do número
        if (numero > 20) {
            System.out.println("O numero e maior do que 20.");
        } else if (numero == 20) {
            System.out.println("O numero e igual a 20.");
        } else {
            System.out.println("O numero e menor do que 20.");
        }
    }
}
