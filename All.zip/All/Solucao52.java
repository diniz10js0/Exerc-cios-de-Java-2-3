public class Solucao52 {
    public static void main(String[] args) {
       
        int numero = 30; 

        // Verificando divisibilidade
        boolean divisivelPor10 = (numero % 10 == 0);
        boolean divisivelPor5 = (numero % 5 == 0);
        boolean divisivelPor2 = (numero % 2 == 0);

        if (divisivelPor10) {
            System.out.println("O numero " + numero + " e divisivel por 10.");
        } else if (divisivelPor5) {
            System.out.println("O numero " + numero + " e divisivel por 5.");
        } else if (divisivelPor2) {
            System.out.println("O numero " + numero + " e divisivel por 2.");
        } else {
            System.out.println("O numero " + numero + " nao é divisivel por 10, 5 ou 2.");
        }
    }
}
