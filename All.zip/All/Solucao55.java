public class Solucao55 {
    public static void main(String[] args) {
  
        int anoNascimento = 2000;         
        int anoAtual = 2024;     

        // Verificando se o ano de nascimento e valido
        if (anoNascimento <= 0 || anoNascimento > anoAtual) {
            System.out.println("Ano de nascimento invalido.");
        } else {
            // Calculando a idade
            int idade = anoAtual - anoNascimento;
            System.out.println("A idade da pessoa e: " + idade + " anos.");
        }
    }
}
