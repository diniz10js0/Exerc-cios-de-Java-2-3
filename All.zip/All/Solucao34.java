import java.util.ArrayList;

public class Solucao34 {
    public static void main(String[] args) {
        // Inicializando contadores
        int contadorPrimos = 0;

        // Simulando a entrada de numeros (substitua por logica de entrada se necessario)
        int[] numerosDigitados = {7, 15, 23, 4, 8, -1}; // Exemplo de entradas

        // Percorrendo os numeros digitados
        for (int numero : numerosDigitados) {
            // Verificando se o numero e nao positivo
            if (numero <= 0) {
                break; // Encerra ao encontrar um numero nao positivo
            }

            // Verificando se o numero e primo
            if (isPrimo(numero)) {
                contadorPrimos++;
            }
        }

        // Imprimindo o total de numeros primos
        System.out.println("Total de numeros primos digitados: " + contadorPrimos);
    }

    public static boolean isPrimo(int num) {
        // Numeros menores que 2 nao sao primos
        if (num < 2) {
            return false;
        }

        // Verificando se o numero é divisuvel por qualquer numero de 2 ate a raiz quadrada do numero
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false; // O numero nao e primo
            }
        }
        return true; // O numero e primo
    }
}
