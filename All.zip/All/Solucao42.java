public class Solucao42 {
    public static void main(String[] args) {
        // Simulando a entrada de dois numeros inteiros
        int valor1 = 10; 
        int valor2 = 8;  

        // Calculando a soma
        int soma = valor1 + valor2;

        // Verificando se a soma e menor ou igual a 20
        if (soma <= 20) {
            soma -= 5; // Subtraindo 5 da soma
        }

        // Apresentando o resultado
        System.out.println("O resultado e: " + soma);
    }
}
