public class Solucao58 {
    public static void main(String[] args) {
        
        int numero1 = 25; 
        int numero2 = 15; 

        // Imprimindo os numeros em ordem crescente
        if (numero1 < numero2) {
            System.out.println("Numeros em ordem crescente: " + numero1 + ", " + numero2);
        } else {
            System.out.println("Numeros em ordem crescente: " + numero2 + ", " + numero1);
        }
    }
}
