public class Solucao3 {
    public static void main(String[] args) {
        // Definindo um verbo no infinitivo
        String verbo = "cantar"; // Você pode alterar para testar outros verbos

        // Verificando a conjugação do verbo
        String resultado = verificarConjugacao(verbo);
        System.out.println(resultado);
    }

    public static String verificarConjugacao(String verbo) {
        if (verbo.endsWith("ar")) {
            return "O verbo e da 1 conjugacao (terminado em 'ar').";
        } else if (verbo.endsWith("er")) {
            return "O verbo e da 2 conjugacao (terminado em 'er').";
        } else if (verbo.endsWith("ir")) {
            return "O verbo e da 3 conjugacao (terminado em 'ir').";
        } else if (!verbo.endsWith("r")) {
            return "O verbo não esta no infinitivo (não termina em 'r').";
        } else if (verbo.endsWith("or") || verbo.endsWith("ur")) {
            return "O verbo provavelmente não e um verbo no infinitivo (termina em 'or' ou 'ur').";
        } else {
            return "Verbo não reconhecido.";
        }
    }
}
