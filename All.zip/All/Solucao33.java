public class Solucao33 {
    public static void main(String[] args) {
        // Simulando a entrada de um numero
        int numero = 29; // Você pode alterar este valor para testar outros numeros

        if (isPrimo(numero)) {
            System.out.println(numero + " e um numero primo.");
        } else {
            System.out.println(numero + " nao e um numero primo.");
        }
    }

    public static boolean isPrimo(int num) {
        // Numeros menores que 2 não sao primos
        if (num < 2) {
            return false;
        }

        // Verificando se o numero e divisivel por qualquer numero de 2 ate a raiz quadrada do numero
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false; // O numero nao e primo
            }
        }
        return true; // O numero e primo
    }
}
