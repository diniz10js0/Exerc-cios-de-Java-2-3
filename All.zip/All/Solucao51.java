public class Solucao51 {
    public static void main(String[] args) {
      
        int numero = 21; 
        // Verificando se o numero e divisivel por 3 e por 7
        boolean divisivelPor3 = (numero % 3 == 0);
        boolean divisivelPor7 = (numero % 7 == 0);

        if (divisivelPor3 && divisivelPor7) {
            System.out.println("O numero " + numero + " e divisivel por 3 e por 7.");
        } else if (divisivelPor3) {
            System.out.println("O numero " + numero + " e divisivel por 3, mas não por 7.");
        } else if (divisivelPor7) {
            System.out.println("O numero " + numero + " e divisivel por 7, mas não por 3.");
        } else {
            System.out.println("O numero " + numero + " nao e divisivel nem por 3 nem por 7.");
        }
    }
}
