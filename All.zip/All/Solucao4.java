public class Solucao4 {
    public static void main(String[] args) {
        // Definindo o nome do aluno
        String nomeAluno = "Carlos"; // Você pode alterar para testar outros nomes

        // Determinando a divisao do aluno
        String divisao = determinarDivisao(nomeAluno);
        System.out.println("O aluno " + nomeAluno + " esta na " + divisao + ".");
    }

    public static String determinarDivisao(String nome) {
        if (nome.isEmpty()) {
            return "Nome invalido.";
        }
        
        char primeiraLetra = Character.toUpperCase(nome.charAt(0));

        if (primeiraLetra >= 'A' && primeiraLetra <= 'K') {
            return "D1";
        } else if (primeiraLetra >= 'L' && primeiraLetra <= 'N') {
            return "D2";
        } else if (primeiraLetra >= 'O' && primeiraLetra <= 'Z') {
            return "D3";
        } else {
            return "Nome fora do padrao.";
        }
    }
}
