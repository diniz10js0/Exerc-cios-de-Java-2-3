public class Solucao47 {
    public static void main(String[] args) {
        
        String nome = "Maria";         
        char sexo = 'F';    
        int idade = 22;        

        // Verificando as condiçoes para aceitaçao
        if ((sexo == 'F' || sexo == 'f') && idade < 25) {
            System.out.println(nome + ", ACEITA.");
        } else {
            System.out.println(nome + ", NÃO ACEITA.");
        }
    }
}
