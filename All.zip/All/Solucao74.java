public class Solucao74 {
    public static void main(String[] args) {
        // Simulando a entrada de cinco numeros
        int numero1 = 10;
        int numero2 = 25; 
        int numero3 = 15; 
        int numero4 = 30; 
        int numero5 = 20; 

        // Inicializando o maior e o menor
        int maior = numero1;
        int menor = numero1;

        // Array para armazenar os numeros
        int[] numeros = {numero1, numero2, numero3, numero4, numero5};

        // Identificando o maior e o menor
        for (int numero : numeros) {
            if (numero > maior) {
                maior = numero;
            }
            if (numero < menor) {
                menor = numero;
            }
        }

        // Imprimindo os resultados
        System.out.println("Maior: " + maior);
        System.out.println("Menor: " + menor);
    }
}
