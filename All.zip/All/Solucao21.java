public class Solucao21 {
    public static void main(String[] args) {
        // Imprimindo números de 100 a 1
        for (int i = 100; i >= 1; i--) {
            System.out.println(i);
        }
    }
}
