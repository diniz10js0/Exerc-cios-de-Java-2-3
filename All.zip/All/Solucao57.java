public class Solucao57 {
    public static void main(String[] args) {
       
        int numero1 = 15;
        int numero2 = 25; 

        // Verificando qual numero e menor
        if (numero1 < numero2) {
            System.out.println("O menor numero e: " + numero1);
        } else {
            System.out.println("O menor numero e: " + numero2);
        }
    }
}
