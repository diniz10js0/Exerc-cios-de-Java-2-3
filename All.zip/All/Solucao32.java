public class Solucao32 {
    public static void main(String[] args) {
        // Inicializando contadores
        int contadorMenor21 = 0;
        int contadorMaior50 = 0;

        // Simulando a entrada de idades
        int[] idadesDigitadas = {20, 22, 55, 18, 75, -1, 30}; 
        // Percorrendo as idades digitadas
        for (int idade : idadesDigitadas) {
            // Verificando se a idade esta fora da faixa
            if (idade < 0 || idade > 120) {
                break; // Encerra ao encontrar uma idade fora da faixa
            }

            // Contando as idades
            if (idade < 21) {
                contadorMenor21++;
            }
            if (idade > 50) {
                contadorMaior50++;
            }
        }

        // Imprimindo os resultados
        System.out.println("Total de pessoas com menos de 21 anos: " + contadorMenor21);
        System.out.println("Total de pessoas com mais de 50 anos: " + contadorMaior50);
    }
}
