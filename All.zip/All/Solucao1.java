public class Solucao1 {
    public static void main(String[] args) {
        // Definindo três lados
        double lado1 = 4.0;
        double lado2 = 8.0;
        double lado3 = 12.0;

        // Verificando se os lados podem formar um triangulo
        if (podeFormarTriangulo(lado1, lado2, lado3)) {
            System.out.println("Os lados podem formar um triângulo.");
        } else {
            System.out.println("Os lados não podem formar um triângulo.");
        }
    }

    public static boolean podeFormarTriangulo(double a, double b, double c) {
        return (a + b > c) && (a + c > b) && (b + c > a);
    }
}
