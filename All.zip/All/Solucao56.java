public class Solucao56 {
    public static void main(String[] args) {
        // Simulando a entrada de dois numeros
        int numero1 = 10; 
        int numero2 = 20; 

        // Verificando se os numeros sao iguais ou diferentes
        if (numero1 == numero2) {
            System.out.println("Os numeros sao iguais.");
        } else {
            System.out.println("Os numeros sao diferentes.");
        }
    }
}
