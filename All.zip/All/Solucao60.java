public class Solucao60 {
    public static void main(String[] args) {
        
        int numero1 = 9;  
        int numero2 = 16; 

        // Calculando o menor e o maior numero
        int menor = Math.min(numero1, numero2);
        int maior = Math.max(numero1, numero2);

        // Imprimindo o quadrado do menor numero e a raiz quadrada do maior numero
        System.out.println("O quadrado do menor numero (" + menor + ") e: " + (menor * menor));
        System.out.println("A raiz quadrada do maior numero (" + maior + ") e: " + Math.sqrt(maior));
    }
}
