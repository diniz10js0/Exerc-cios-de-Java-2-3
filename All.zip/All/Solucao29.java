public class Solucao29 {
    public static void main(String[] args) {
        int soma = 0;

        // Imprimindo números de 1 a 100 e calculando a soma
        for (int i = 1; i <= 100; i++) {
            System.out.println(i);
            soma += i; // Adiciona o numero atual a soma
        }

        // Imprimindo a soma
        System.out.println("A soma de todos os numeros de 1 a 100 e: " + soma);
    }
}
