public class Solucao31 {
    public static void main(String[] args) {
        // Inicializando variaveis
        int codigo;
        double totalResidencial = 0, totalComercial = 0, totalIndustrial = 0;
        double consumoResidencial = 0, consumoComercial = 0;
        int contadorResidencial = 0, contadorComercial = 0;

        // Simulando a entrada de dados
        int[] codigos = {101, 102, 103, 0}; 
        double[] consumos = {150, 200, 300}; // Exemplo de consumos em kWh
        int[] tipos = {1, 2, 3}; // Tipos de consumidor

        // Lendo os dados ate encontrar codigo 0
        for (int i = 0; i < codigos.length; i++) {
            codigo = codigos[i];
            if (codigo == 0) {
                break; // Encerrar ao encontrar codigo 0
            }

            double consumo = consumos[i];
            int tipo = tipos[i];
            double custo = 0;

            // Calculando o custo e acumulando totais
            switch (tipo) {
               
                case 1: // Residencial
                    custo = consumo * 0.3;
                    totalResidencial += custo;
                    consumoResidencial += consumo;
                    contadorResidencial++;
                    break;
                
                case 2: // Comercial
                    custo = consumo * 0.5;
                    totalComercial += custo;
                    consumoComercial += consumo;
                    contadorComercial++;
                    break;
                case 3: // Industrial
                    custo = consumo * 0.7;
                    totalIndustrial += custo;
                    break;
            }

            // Imprimindo o custo para o consumidor
            System.out.println("Codigo do consumidor: " + codigo);
            System.out.println("Custo total: R$ " + custo);
            System.out.println();
        }

        // Imprimindo os totais e medias
        System.out.println("Total de consumo residencial: R$ " + totalResidencial);
        System.out.println("Total de consumo comercial: R$ " + totalComercial);
        System.out.println("Total de consumo industrial: R$ " + totalIndustrial);
        
        double mediaConsumo = (contadorResidencial + contadorComercial > 0) ? 
            (consumoResidencial + consumoComercial) / (contadorResidencial + contadorComercial) : 0;
        System.out.println("Media de consumo dos tipos 1 e 2: " + mediaConsumo + " kWh");
    }
}
