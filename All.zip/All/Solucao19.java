public class Solucao19 {
    public static void main(String[] args) {
        
        int numero1 = 15; 
        int numero2 = 25;

        // Imprimindo os numeros em ordem decrescente
        if (numero1 > numero2) {
            System.out.println("Numeros em ordem decrescente: " + numero1 + ", " + numero2);
        } else {
            System.out.println("Numeros em ordem decrescente: " + numero2 + ", " + numero1);
        }
    }
}
