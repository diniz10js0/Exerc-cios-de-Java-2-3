public class Solucao23 {
    public static void main(String[] args) {
        // Definindo um array de números para simular a entrada
        double[] numeros = {10, 20, 30, 40, 50}; // Você pode alterar ou adicionar mais números
        double soma = 0;
        int contador = 0;

        // Calculando a soma e contando os números
        for (double numero : numeros) {
            if (numero > 0) {
                soma += numero;
                contador++;
            }
        }

        // Calculando e imprimindo a média
        if (contador > 0) {
            double media = soma / contador;
            System.out.println("A media dos numeros positivos digitados e: " + media);
            } else {
            System.out.println("Nenhum número positivo foi digitado.");
        }
    }
}
       
