public class Solucao35 {
    public static void main(String[] args) {
        // Inicializando variaveis
        int numero;
        int maior = Integer.MIN_VALUE; 

        // Simulando a entrada de numeros 
        int[] numerosDigitados = {10, 45, 23, 89, 12, -9999}; 

        // Percorrendo os numeros digitados
        for (int i = 0; i < numerosDigitados.length; i++) {
            numero = numerosDigitados[i];

            // Verificando se o numero é -9999 para encerrar
            if (numero == -9999) {
                break; // Encerra ao encontrar -9999
            }

            // Atualizando o maior numero encontrado
            if (numero > maior) {
                maior = numero;
            }
        }

        // Imprimindo o maior numero encontrado
        if (maior != Integer.MIN_VALUE) {
            System.out.println("O maior numero digitado foi: " + maior);
        } else {
            System.out.println("Nenhum numero valido foi digitado.");
        }
    }
}
