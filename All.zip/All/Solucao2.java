public class Solucao2 {
    public static void main(String[] args) {
        // Definindo três lados
        double lado1 = 5.0;
        double lado2 = 5.0;
        double lado3 = 8.0;

        // Verificando se os lados podem formar um triangulo
        if (podeFormarTriangulo(lado1, lado2, lado3)) {
            String tipoTriangulo = tipoTriangulo(lado1, lado2, lado3);
            System.out.println("Os lados formam um triangulo " + tipoTriangulo + ".");
        } else {
            System.out.println("Os lados não podem formar um triangulo.");
        }
    }

    public static boolean podeFormarTriangulo(double a, double b, double c) {
        return (a + b > c) && (a + c > b) && (b + c > a);
    }

    public static String tipoTriangulo(double a, double b, double c) {
        if (a == b && b == c) {
            return "equilatero";
        } else if (a == b || a == c || b == c) {
            return "isosceles";
        } else {
            return "escaleno";
        }
    }
}
