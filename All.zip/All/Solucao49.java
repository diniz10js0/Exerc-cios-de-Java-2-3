public class Solucao49 {
    public static void main(String[] args) {
        // Simulando a entrada de um numero
        int numero = 9; // Você pode alterar este valor

        // Verificando se o numero e multiplo de 3
        if (numero % 3 == 0) {
            System.out.println("O numero " + numero + " e multiplo de 3.");
        } else {
            System.out.println("O numero " + numero + " nao e multiplo de 3.");
        }
    }
}
