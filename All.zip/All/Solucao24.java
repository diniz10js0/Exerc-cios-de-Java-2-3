public class Solucao24 {
    public static void main(String[] args) {
        // Inicializando variaveis
        int numero;
        int contador = 0;

        // Simulando a entrada de numeros
               int[] numerosDigitados = {150, 75, 200, 99, 105, 0, 250, 130}; // Exemplo de entrada

        for (int i = 0; i < numerosDigitados.length; i++) {
            numero = numerosDigitados[i];

            // Verificando se o numero e 0 para encerrar
            if (numero == 0) {
                break;
            }

            // Verificando se o numero esta entre 100 e 200
            if (numero >= 100 && numero <= 200) {
                contador++;
            }
        }

        // Imprimindo o resultado
        System.out.println("Foram digitados " + contador + " numeros entre 100 e 200.");
    }
}
